#pragma once

#include "cards/CardInstanceFactory.hpp"
#include "cards/DrawSystem.hpp"
#include "combat/BlockSystem.hpp"
#include "combat/CardPlaySystem.hpp"
#include "combat/CardPlayValidator.hpp"
#include "combat/CombatController.hpp"
#include "combat/CombatOutcome.hpp"
#include "combat/CombatResult.hpp"
#include "combat/CombatState.hpp"
#include "combat/DamageSystem.hpp"
#include "combat/EffectResolver.hpp"
#include "combat/EffectSystem.hpp"
#include "combat/EnergySystem.hpp"
#include "combat/EnemyMoveSelector.hpp"
#include "combat/EnemyTurnSystem.hpp"
#include "combat/ModifierSystem.hpp"
#include "combat/PlayerTurnSystem.hpp"
#include "combat/Targeting.hpp"
#include "combat/TurnSystem.hpp"
#include "consumables/ConsumableSystem.hpp"
#include "core/Random.hpp"
#include "data/ContentRegistry.hpp"
#include "effects/EffectDefinition.hpp"
#include "effects/EffectValue.hpp"
#include "game/GameEventBus.hpp"
#include "inspect/InspectModelBuilder.hpp"
#include "localization/LocalizationManager.hpp"
#include "localization/TextFormatter.hpp"
#include "preview/CardPreviewSystem.hpp"
#include "relics/RelicSystem.hpp"
#include "rewards/RewardSelection.hpp"
#include "rewards/RewardState.hpp"
#include "run/RunState.hpp"
#include "scenes/Scene.hpp"
#include "statuses/StatusSystem.hpp"
#include "ui/CardViewModel.hpp"
#include "ui/CardViewModelBuilder.hpp"
#include "ui/CombatView.hpp"
#include "ui/CombatViewModelBuilder.hpp"
#include "ui/EnemyViewModel.hpp"
#include "ui/InspectPanelView.hpp"
#include "ui/RelicInspectModal.hpp"
#include "ui/RelicViewModel.hpp"
#include "ui/UiFont.hpp"

#include <raylib.h>

#include <cstddef>
#include <filesystem>
#include <functional>
#include <optional>
#include <string>
#include <vector>

class CombatScene final : public Scene {
public:
    CombatScene(
        const ContentRegistry& content,
        const LocalizationManager& localization,
        Random& random,
        const UiFont& uiFont,
        const RunState& runState,
        std::function<RewardState(const CombatResult&)> createRewardOnVictory,
        std::function<void(const RewardState&, const RewardSelection&)> onRewardAccepted,
        std::function<void(const CombatResult&)> onCombatLost
    );

    void update(float deltaSeconds) override;
    void render() const override;

private:
    void initializeCombat();
    void rebuildViewModel(std::optional<EntityId> previewTarget);
    EntityId primaryPlayerId() const;
    EntityId sourceForCard(const CardInstance& card) const;
    EntityId sourceForCard(CardInstanceId cardInstanceId) const;
    bool isSadistMasochistParty() const;
    std::vector<RelicViewModel> buildRelicViewModels() const;

    void updateInspectInput(Vector2 mousePosition);
    void renderInspectOverlay() const;
    std::optional<EnemyViewModel> hoveredEnemyViewModel() const;
    std::optional<CardViewModel> inspectedCardViewModel() const;

    void handleMousePressed(Vector2 mousePosition);
    void tryUseHoveredConsumable();
    void handleMouseReleased(Vector2 mousePosition);
    void playSelectedCardOn(EntityId target);
    void endPlayerTurn();

    bool selectedCardCanTargetEnemy() const;
    bool selectedCardCanTargetPlayer() const;
    bool cardCanTargetEnemy(CardInstanceId cardInstanceId) const;
    bool cardCanTargetPlayer(CardInstanceId cardInstanceId) const;

    void finishCombatIfNeeded();

    void openRewardModalIfNeeded();
    void updateRewardModalInput(Vector2 mousePosition);
    void renderRewardModal() const;
    void renderDefeatModal() const;

    Rectangle rewardModalBounds() const;
    Rectangle rewardOptionRowBounds(std::size_t index) const;
    Rectangle rewardContinueButtonBounds() const;

    Rectangle rewardCardChoiceModalBounds() const;
    Rectangle rewardCardChoiceOptionBounds(std::size_t index) const;
    Rectangle rewardCardChoiceCancelBounds() const;
    Rectangle rewardCardChoiceConfirmBounds() const;

    void openRewardCardChoice(std::size_t optionIndex);
    void closeRewardCardChoice();
    void confirmRewardCardChoice();
    void takeRewardOption(std::size_t optionIndex);

    void updateRewardCardChoiceInput(Vector2 mousePosition);
    void renderRewardCardChoiceModal() const;

    const RewardOption* activeRewardOption() const;
    RewardOption* activeRewardOption();

    std::string rewardOptionTitle(const RewardOption& option) const;
    std::string rewardOptionDescription(const RewardOption& option) const;
    std::string rewardCardName(const CardId& cardId) const;
    std::string rewardCardDescription(const CardId& cardId) const;
    std::string localizedOrFallback(const TextId& textId, const std::string& fallback) const;

    static std::string effectValueText(const EffectValue& value);
    static std::string rangeToString(int minimum, int maximum);
    static void fillVariablesFromEffect(
        TextFormatter::Variables& variables,
        const EffectDefinition& effect
    );

private:
    const ContentRegistry& content_;
    const LocalizationManager& localization_;
    Random& random_;
    const UiFont& uiFont_;
    const RunState& runState_;

    std::function<RewardState(const CombatResult&)> createRewardOnVictory_;
    std::function<void(const RewardState&, const RewardSelection&)> onRewardAccepted_;
    std::function<void(const CombatResult&)> onCombatLost_;

    GameEventBus eventBus_;
    ModifierSystem modifierSystem_;
    CombatController combatController_;
    RelicSystem relicSystem_;
    EffectResolver effectResolver_;
    Targeting targeting_;
    DamageSystem damageSystem_;
    BlockSystem blockSystem_;
    EnergySystem energySystem_;
    DrawSystem drawSystem_;
    StatusSystem statusSystem_;
    ConsumableSystem consumableSystem_;
    CardPlayValidator validator_;
    EffectSystem effectSystem_;
    CardPlaySystem cardPlaySystem_;
    CardPreviewSystem previewSystem_;

    EnemyMoveSelector enemyMoveSelector_;
    PlayerTurnSystem playerTurnSystem_;
    EnemyTurnSystem enemyTurnSystem_;
    TurnSystem turnSystem_;

    CardViewModelBuilder cardViewModelBuilder_;
    CombatViewModelBuilder combatViewModelBuilder_;
    InspectModelBuilder inspectModelBuilder_;

    CombatState state_;
    CombatResult finalResult_;
    EntityIdGenerator entityIds_;
    CardInstanceFactory cardFactory_;

    EntityId playerId_;
    std::vector<std::string> combatConsumableIds_;
    std::optional<CardInstanceId> selectedCardId_;
    std::optional<CardInstanceId> draggedCardId_;

    CombatView view_;
    InspectPanelView inspectPanelView_;
    RelicInspectModal relicInspectModal_;
    std::optional<CardInstanceId> inspectedCardId_;

    std::optional<RewardState> reward_;
    RewardSelection rewardSelection_;
    std::optional<std::size_t> activeRewardOptionIndex_;
    std::optional<std::size_t> selectedRewardCardIndex_;
    bool rewardCardChoiceOpen_ = false;
    bool rewardAccepted_ = false;

    bool viewModelDirty_ = true;
    bool combatFinished_ = false;
    std::optional<EntityId> lastPreviewTarget_;
};
