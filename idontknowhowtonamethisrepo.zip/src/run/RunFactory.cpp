#include "RunFactory.hpp"

#include "core/Random.hpp"
#include "run/RunMapGenerator.hpp"
#include "run/RunRelicOwnership.hpp"
#include "run/StressRules.hpp"

#include <cstddef>
#include <string>
#include <utility>

RunState RunFactory::createRun(
    const PlayableArchetypeDefinition& archetype,
    const DifficultyDefinition& difficulty,
    const PlayerActorDatabase& actors,
    const RunMapGenerationConfig& mapGeneration,
    const FloorDefinition& floor,
    const std::uint32_t seed
) const {
    RunMapGenerator generator;
    Random mapRandom(seed);

    RunState run;
    run.archetypeId = archetype.id;
    run.difficultyId = difficulty.id;
    run.archetypeMechanicId = archetype.mechanicId;
    run.seed = seed;
    run.gold = archetype.startingGold;
    run.act = floor.act;
    run.currentFloorId = floor.id;
    run.currentFloorIndex = floor.index;
    run.nextFloorId = floor.nextFloorId;
    run.enemyHpMultiplier = difficulty.enemyHpMultiplier;
    run.enemyDamageMultiplier = difficulty.enemyDamageMultiplier;
    run.goldRewardMultiplier = difficulty.goldMultiplier;
    run.actorDefinitionIds = archetype.actorDefinitionIds;
    run.rewardCardPoolIds = archetype.rewardCardPoolIds;
    if (run.rewardCardPoolIds.empty()) {
        run.rewardCardPoolIds = run.actorDefinitionIds;
    }
    run.actorStates.reserve(archetype.actorDefinitionIds.size());
    for (const std::string& actorId : archetype.actorDefinitionIds) {
        const PlayerActorDefinition& actor = actors.get(PlayerActorId(actorId));
        RunActorState actorState;
        actorState.definitionId = actorId;
        actorState.currentHp = actor.maxHp;
        actorState.maxHp = actor.maxHp;
        actorState.stress = 0;
        actorState.maxStress = StressRules::MaximumStress;
        actorState.resolveCheckTriggered = false;
        actorState.traitIds = actor.startingTraitIds;
        run.actorStates.push_back(std::move(actorState));
    }

    for (std::size_t index = 0; index < archetype.startingRelicIds.size(); ++index) {
        if (run.actorStates.empty()) {
            run.relicIds.push_back(archetype.startingRelicIds[index]);
            continue;
        }

        const std::string& ownerActor = run.actorStates[index % run.actorStates.size()].definitionId;
        RunRelicOwnership::assignRelicToActor(run, archetype.startingRelicIds[index], ownerActor);
    }

    run.deckCardIds.reserve(archetype.startingDeckCardIds.size());
    for (const std::string& cardId : archetype.startingDeckCardIds) {
        run.deckCardIds.emplace_back(cardId);
    }

    run.map = generator.generateActOneMap(mapRandom, mapGeneration);
    run.randomState = mapRandom.state();
    return run;
}
