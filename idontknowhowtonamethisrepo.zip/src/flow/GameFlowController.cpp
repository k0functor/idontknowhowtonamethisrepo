#include "GameFlowController.hpp"

#include "relics/RelicId.hpp"
#include "scenes/CombatScene.hpp"
#include "scenes/DifficultySelectScene.hpp"
#include "scenes/MainMenuScene.hpp"
#include "scenes/ProfileHubScene.hpp"
#include "scenes/RunMapScene.hpp"
#include "scenes/SaveSlotScene.hpp"
#include "scenes/SplashScene.hpp"

#include <iostream>
#include <stdexcept>
#include <utility>

GameFlowController::GameFlowController(
    const ContentRegistry& content,
    const LocalizationManager& localization,
    Random& random,
    const std::filesystem::path& assetsPath
)
    : content_(content),
      localization_(localization),
      random_(random) {
    if (!uiFont_.loadFromAssetsDirectory(assetsPath)) {
        std::cout << "UI font was not found. Put a Unicode font at assets/fonts/main.ttf.\n";
    } else {
        std::cout << "Loaded UI font: " << uiFont_.loadedPath().string() << '\n';
    }

    setSplashScene();
}

void GameFlowController::update(const float deltaSeconds) {
    sceneManager_.update(deltaSeconds);
    executePendingTransition();
}

void GameFlowController::render() const {
    sceneManager_.render();
}

bool GameFlowController::exitRequested() const {
    return exitRequested_;
}

void GameFlowController::queueTransition(std::function<void()> transition) {
    pendingTransition_ = std::move(transition);
}

void GameFlowController::executePendingTransition() {
    if (!pendingTransition_) {
        return;
    }

    std::function<void()> transition = std::move(pendingTransition_);
    pendingTransition_ = nullptr;
    transition();
}

void GameFlowController::setSplashScene() {
    sceneManager_.setScene(
        std::make_unique<SplashScene>(
            uiFont_,
            [this]() { showMainMenu(); }
        )
    );
}

void GameFlowController::setMainMenuScene() {
    sceneManager_.setScene(
        std::make_unique<MainMenuScene>(
            uiFont_,
            [this]() { showSaveSlots(); },
            [this]() { requestExit(); }
        )
    );
}

void GameFlowController::setSaveSlotScene() {
    sceneManager_.setScene(
        std::make_unique<SaveSlotScene>(
            uiFont_,
            profileManager_,
            [this](const std::size_t slotIndex) { selectProfileSlot(slotIndex); },
            [this]() { showMainMenu(); }
        )
    );
}

void GameFlowController::setProfileHubScene() {
    sceneManager_.setScene(
        std::make_unique<ProfileHubScene>(
            uiFont_,
            localization_,
            content_.actors(),
            content_.cards(),
            content_.archetypes().all(),
            [this](PlayableArchetypeId archetypeId) { selectArchetype(std::move(archetypeId)); },
            [this]() { showSaveSlots(); }
        )
    );
}

void GameFlowController::setDifficultySelectScene() {
    sceneManager_.setScene(
        std::make_unique<DifficultySelectScene>(
            uiFont_,
            localization_,
            content_.difficulties().all(),
            [this](DifficultyId difficultyId) { selectDifficulty(std::move(difficultyId)); },
            [this]() { queueTransition([this]() { setProfileHubScene(); }); }
        )
    );
}

void GameFlowController::setRunMapScene() {
    if (!runController_.hasActiveRun()) {
        throw std::runtime_error("Cannot open run map: no active run");
    }

    sceneManager_.setScene(
        std::make_unique<RunMapScene>(
            uiFont_,
            runController_.run(),
            [this](const int nodeId) { startMapNode(nodeId); },
            [this](const int nodeId) { restHeal(nodeId); },
            [this](const int nodeId) { restUpgrade(nodeId); },
            [this]() { queueTransition([this]() { setProfileHubScene(); }); }
        )
    );
}

void GameFlowController::setCombatScene(const int nodeId) {
    if (!runController_.hasActiveRun()) {
        throw std::runtime_error("Cannot start combat: no active run");
    }

    sceneManager_.setScene(
        std::make_unique<CombatScene>(
            content_,
            localization_,
            random_,
            uiFont_,
            runController_.run(),
            [this, nodeId](const CombatResult& result) {
                return runController_.completeCombatAndCreateReward(
                    nodeId,
                    result,
                    content_.cards(),
                    content_.relics(),
                    random_
                );
            },
            [this](const RewardState& reward, RewardSelection selection) {
                finishReward(reward, std::move(selection));
            },
            [this](const CombatResult&) {
                queueTransition([this]() { setProfileHubScene(); });
            }
        )
    );
}

void GameFlowController::showMainMenu() {
    queueTransition([this]() { setMainMenuScene(); });
}

void GameFlowController::showSaveSlots() {
    queueTransition([this]() { setSaveSlotScene(); });
}

void GameFlowController::selectProfileSlot(const std::size_t slotIndex) {
    queueTransition([this, slotIndex]() {
        profileManager_.selectSlot(slotIndex);
        setProfileHubScene();
    });
}

void GameFlowController::selectArchetype(PlayableArchetypeId archetypeId) {
    queueTransition([this, archetypeId = std::move(archetypeId)]() mutable {
        selectedArchetypeId_ = std::move(archetypeId);
        setDifficultySelectScene();
    });
}

void GameFlowController::selectDifficulty(DifficultyId difficultyId) {
    queueTransition([this, difficultyId = std::move(difficultyId)]() mutable {
        if (!selectedArchetypeId_.has_value()) {
            throw std::runtime_error("Cannot select difficulty before archetype");
        }

        selectedDifficultyId_ = difficultyId;

        const PlayableArchetypeDefinition& archetype = content_.archetypes().get(*selectedArchetypeId_);
        const DifficultyDefinition& difficulty = content_.difficulties().get(difficultyId);

        runController_.startNewRun(archetype, difficulty, random_.seed());
        setRunMapScene();
    });
}

void GameFlowController::startMapNode(const int nodeId) {
    queueTransition([this, nodeId]() {
        const RunMapNodeType nodeType = runController_.node(nodeId).type;
        runController_.startNode(nodeId);

        switch (nodeType) {
            case RunMapNodeType::Combat:
            case RunMapNodeType::Elite:
            case RunMapNodeType::Boss:
                setCombatScene(nodeId);
                return;

            case RunMapNodeType::Chest: {
                const std::optional<RelicId> relic = runController_.chooseChestRelic(content_.relics(), random_);
                if (relic.has_value()) {
                    runController_.completeChestAndTakeRelic(nodeId, *relic);
                } else {
                    runController_.completeEventNode(nodeId);
                }
                setRunMapScene();
                return;
            }

            case RunMapNodeType::Event:
            case RunMapNodeType::Shop:
                runController_.completeEventNode(nodeId);
                setRunMapScene();
                return;

            case RunMapNodeType::Rest:
                // Rest is normally handled inside RunMapScene through its modal.
                setRunMapScene();
                return;
        }
    });
}

void GameFlowController::restHeal(const int nodeId) {
    queueTransition([this, nodeId]() {
        runController_.startNode(nodeId);
        runController_.completeRestHeal(nodeId);
        setRunMapScene();
    });
}

void GameFlowController::restUpgrade(const int nodeId) {
    queueTransition([this, nodeId]() {
        runController_.startNode(nodeId);
        runController_.completeRestUpgrade(nodeId);
        setRunMapScene();
    });
}

void GameFlowController::finishReward(const RewardState& reward, RewardSelection selection) {
    queueTransition([this, reward, selection = std::move(selection)]() mutable {
        runController_.applyReward(reward, selection);
        setRunMapScene();
    });
}

void GameFlowController::requestExit() {
    queueTransition([this]() { exitRequested_ = true; });
}
