#include "RewardGenerator.hpp"

#include "cards/CardRarity.hpp"
#include "cards/CardType.hpp"
#include "rewards/RewardOption.hpp"

#include <algorithm>
#include <stdexcept>
#include <vector>

namespace {
bool canAppearAsCombatReward(const CardDefinition& card) {
    if (card.type == CardType::Status || card.type == CardType::Curse) {
        return false;
    }

    if (card.rarity == CardRarity::Starter || card.rarity == CardRarity::Special) {
        return false;
    }

    return true;
}
}

RewardState RewardGenerator::generateCombatReward(
    const RewardContext& context,
    const CardDatabase& cards,
    const RelicDatabase& relics,
    Random& random
) const {
    RewardState reward;
    reward.sourceNodeType = context.nodeType;

    const int baseGold = baseGoldForNode(context.nodeType);
    int gold = static_cast<int>(static_cast<float>(baseGold) * context.run.goldRewardMultiplier);
    gold = static_cast<int>(static_cast<double>(gold) * relicGoldMultiplier(context, relics));

    if (context.run.archetypeMechanicId == "merchant_progression") {
        gold = static_cast<int>(static_cast<float>(gold) * 1.25f);
    }

    if (gold > 0) {
        reward.options.push_back(RewardOption::goldReward(gold));
    }

    if (!shouldOfferCards(context)) {
        return reward;
    }

    std::vector<const CardDefinition*> candidates;
    for (const CardDefinition* card : cards.all()) {
        if (card != nullptr && canAppearAsCombatReward(*card)) {
            candidates.push_back(card);
        }
    }

    if (candidates.empty()) {
        return reward;
    }

    const int optionCount = std::min<int>(cardRewardCount(context), static_cast<int>(candidates.size()));
    std::vector<CardRewardOption> cardOptions;
    cardOptions.reserve(static_cast<std::size_t>(optionCount));

    for (int i = 0; i < optionCount; ++i) {
        const int pickedIndex = random.rangeInclusive(0, static_cast<int>(candidates.size()) - 1);
        const CardDefinition* picked = candidates[static_cast<std::size_t>(pickedIndex)];

        cardOptions.push_back(CardRewardOption{picked->id});
        candidates.erase(candidates.begin() + pickedIndex);
    }

    if (!cardOptions.empty()) {
        reward.options.push_back(RewardOption::cardChoice(std::move(cardOptions)));
    }

    return reward;
}

int RewardGenerator::baseGoldForNode(const RunMapNodeType nodeType) const {
    switch (nodeType) {
        case RunMapNodeType::Combat:
            return 18;
        case RunMapNodeType::Elite:
            return 35;
        case RunMapNodeType::Boss:
            return 75;
        case RunMapNodeType::Chest:
        case RunMapNodeType::Event:
        case RunMapNodeType::Shop:
        case RunMapNodeType::Rest:
            return 0;
    }

    throw std::runtime_error("Unknown RunMapNodeType in RewardGenerator");
}

bool RewardGenerator::shouldOfferCards(const RewardContext& context) const {
    if (context.run.archetypeMechanicId == "merchant_progression") {
        return false;
    }

    return context.nodeType == RunMapNodeType::Combat ||
        context.nodeType == RunMapNodeType::Elite ||
        context.nodeType == RunMapNodeType::Boss;
}

int RewardGenerator::cardRewardCount(const RewardContext&) const {
    return 3;
}


double RewardGenerator::relicGoldMultiplier(
    const RewardContext& context,
    const RelicDatabase& relics
) const {
    double result = 1.0;

    for (const std::string& relicId : context.run.relicIds) {
        const RelicId id(relicId);

        if (!relics.contains(id)) {
            continue;
        }

        const RelicDefinition& relic = relics.get(id);

        for (const RelicModifierDefinition& modifier : relic.modifiers) {
            if (modifier.type == RelicModifierType::GoldRewardMultiply) {
                result *= modifier.multiplier;
            }
        }
    }

    return result;
}
